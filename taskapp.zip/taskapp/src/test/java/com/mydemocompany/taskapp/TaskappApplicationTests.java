package com.mydemocompany.taskapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskappApplicationTests {

    @Test
    void contextLoads() {
    }

}
